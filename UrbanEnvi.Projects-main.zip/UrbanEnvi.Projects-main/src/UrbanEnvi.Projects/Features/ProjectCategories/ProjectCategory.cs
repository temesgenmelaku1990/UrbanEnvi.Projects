﻿namespace UrbanEnvi.Features.ProjectCategories;

public class ProjectCategory : Entity<Guid>
{
    public string Name { get; set; } = null!;
}
