﻿namespace UrbanEnvi.Features.AssessmentTypes;

public enum CoreAssessmentType
{
    Glare = 1,
    Helipad = 2,
    Indoor = 3,
    Shadow = 4,
    Solar = 5,
    Wind = 6
}
